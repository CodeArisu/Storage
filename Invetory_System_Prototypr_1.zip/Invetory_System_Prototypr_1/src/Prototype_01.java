
import java.awt.Color;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author ROLANDO GERONA JR
 */
public class Prototype_01 extends javax.swing.JFrame {

    int Xmouse;
    int Ymouse;
    
    public Prototype_01() {
        initComponents();
    }

  
    @SuppressWarnings("unchecked")
    
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSpinner1 = new javax.swing.JSpinner();
        db = new javax.swing.JPanel();
        drag = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        minimize = new javax.swing.JLabel();
        leftPanel = new javax.swing.JPanel();
        menu1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        menu2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        menu3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Title = new javax.swing.JPanel();
        jLabel45 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        searchBar = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Item_Qty = new javax.swing.JTextField();
        Item_Type = new javax.swing.JTextField();
        Item_Name = new javax.swing.JTextField();
        Item_id = new javax.swing.JTextField();
        add_button = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel38 = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        sizeBox = new java.awt.Checkbox();
        jLabel40 = new javax.swing.JLabel();
        choice1 = new java.awt.Choice();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        db.setBackground(new java.awt.Color(255, 255, 255));
        db.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        drag.setBackground(new java.awt.Color(255, 255, 255));
        drag.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(204, 204, 255), new java.awt.Color(204, 204, 255), null, null));
        drag.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                dragMouseDragged(evt);
            }
        });
        drag.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dragMousePressed(evt);
            }
        });
        drag.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 0, 51));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/close_30px.png"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jLabel1MouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel1MousePressed(evt);
            }
        });
        drag.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1430, 0, 30, 40));

        jLabel2.setFont(new java.awt.Font("Myanmar Text", 0, 14)); // NOI18N
        jLabel2.setText("INVENTORY_SYSTEM");
        drag.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, -1, 30));

        minimize.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_subtract_30px.png"))); // NOI18N
        minimize.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                minimizeMousePressed(evt);
            }
        });
        drag.add(minimize, new org.netbeans.lib.awtextra.AbsoluteConstraints(1390, 0, 30, 40));

        db.add(drag, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 1490, 40));

        leftPanel.setBackground(new java.awt.Color(56, 75, 144));
        leftPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        menu1.setBackground(new java.awt.Color(56, 75, 144));
        menu1.setForeground(new java.awt.Color(51, 51, 255));
        menu1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        menu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                menu1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                menu1MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                menu1MousePressed(evt);
            }
        });
        menu1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_home_30px.png"))); // NOI18N
        menu1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 40, 50));

        jLabel5.setFont(new java.awt.Font("Myanmar Text", 1, 16)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 204, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("DASHBOARD");
        menu1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 120, 40));

        leftPanel.add(menu1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 170, 90));

        menu2.setBackground(new java.awt.Color(56, 75, 144));
        menu2.setForeground(new java.awt.Color(51, 51, 255));
        menu2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        menu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                menu2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                menu2MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                menu2MousePressed(evt);
            }
        });
        menu2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Myanmar Text", 1, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(204, 204, 255));
        jLabel10.setText("RECORDS");
        menu2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 50, 80, 40));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_in_inventory_30px.png"))); // NOI18N
        menu2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 40, 50));

        leftPanel.add(menu2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 170, 90));

        menu3.setBackground(new java.awt.Color(56, 75, 144));
        menu3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                menu3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                menu3MouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                menu3MousePressed(evt);
            }
        });
        menu3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_contacts_40px.png"))); // NOI18N
        menu3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 50, 50));

        jLabel4.setFont(new java.awt.Font("Myanmar Text", 1, 16)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("ACCOUNT");
        menu3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 110, 40));

        leftPanel.add(menu3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 170, 90));

        Title.setBackground(new java.awt.Color(143, 158, 214));
        Title.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel45.setBackground(new java.awt.Color(102, 102, 255));
        jLabel45.setFont(new java.awt.Font("Myanmar Text", 1, 48)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(225, 225, 250));
        jLabel45.setText("I");
        Title.add(jLabel45, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 20, 70));

        jLabel43.setBackground(new java.awt.Color(102, 102, 255));
        jLabel43.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(225, 225, 250));
        jLabel43.setText("NVENTORY");
        Title.add(jLabel43, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 110, 60));

        jLabel41.setBackground(new java.awt.Color(102, 102, 255));
        jLabel41.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(225, 225, 250));
        jLabel41.setText("YSTEM");
        Title.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 30, -1, 60));

        jLabel42.setBackground(new java.awt.Color(102, 102, 255));
        jLabel42.setFont(new java.awt.Font("Myanmar Text", 1, 36)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(225, 225, 250));
        jLabel42.setText("S");
        Title.add(jLabel42, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 30, 50));

        leftPanel.add(Title, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 130, 80));

        db.add(leftPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 170, 700));

        jPanel2.setBackground(new java.awt.Color(56, 75, 144));
        jPanel2.setForeground(new java.awt.Color(153, 153, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        searchBar.setBackground(new java.awt.Color(191, 200, 233));
        searchBar.setFont(new java.awt.Font("Myanmar Text", 0, 18)); // NOI18N
        searchBar.setForeground(new java.awt.Color(51, 51, 51));
        searchBar.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(204, 204, 204), 2, true));
        searchBar.setCaretColor(new java.awt.Color(0, 0, 51));
        searchBar.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        searchBar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBarActionPerformed(evt);
            }
        });
        jPanel2.add(searchBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(950, 40, 280, 30));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_home_60px.png"))); // NOI18N
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 20, 60, -1));

        jLabel44.setBackground(new java.awt.Color(102, 102, 255));
        jLabel44.setFont(new java.awt.Font("Myanmar Text", 1, 36)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(225, 225, 250));
        jLabel44.setText("DASHBOARD");
        jPanel2.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 40, -1, 60));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_search_30px.png"))); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(1240, 40, 30, 30));

        db.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 40, 1290, 90));

        jPanel1.setBackground(new java.awt.Color(37, 51, 101));
        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(75, 75, 137), 0, true));
        jPanel1.setForeground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Item_Qty.setBackground(new java.awt.Color(191, 200, 233));
        Item_Qty.setFont(new java.awt.Font("Myanmar Text", 0, 18)); // NOI18N
        Item_Qty.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        Item_Qty.setBorder(null);
        Item_Qty.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Item_Qty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Item_QtyActionPerformed(evt);
            }
        });
        jPanel1.add(Item_Qty, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 80, 30));

        Item_Type.setBackground(new java.awt.Color(191, 200, 233));
        Item_Type.setFont(new java.awt.Font("Myanmar Text", 0, 18)); // NOI18N
        Item_Type.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        Item_Type.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Item_Type.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Item_Type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Item_TypeActionPerformed(evt);
            }
        });
        jPanel1.add(Item_Type, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 210, 30));

        Item_Name.setBackground(new java.awt.Color(191, 200, 233));
        Item_Name.setFont(new java.awt.Font("Myanmar Text", 0, 18)); // NOI18N
        Item_Name.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        Item_Name.setBorder(null);
        Item_Name.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Item_Name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Item_NameActionPerformed(evt);
            }
        });
        jPanel1.add(Item_Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 210, 30));

        Item_id.setBackground(new java.awt.Color(191, 200, 233));
        Item_id.setFont(new java.awt.Font("Myanmar Text", 0, 18)); // NOI18N
        Item_id.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        Item_id.setBorder(null);
        Item_id.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        Item_id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Item_idActionPerformed(evt);
            }
        });
        jPanel1.add(Item_id, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 290, 80, 30));

        add_button.setBackground(new java.awt.Color(51, 71, 140));
        add_button.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        add_button.setForeground(new java.awt.Color(204, 204, 255));
        add_button.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        add_button.setText("ADD");
        add_button.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        add_button.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        add_button.setOpaque(true);
        jPanel1.add(add_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 490, 80, 40));

        jLabel37.setBackground(new java.awt.Color(102, 102, 255));
        jLabel37.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(204, 204, 255));
        jLabel37.setText("Qty.");
        jPanel1.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, -1, 50));

        jLabel38.setBackground(new java.awt.Color(102, 102, 255));
        jLabel38.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(204, 204, 255));
        jLabel38.setText("Item Name");
        jPanel1.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, -1, 30));

        jLabel39.setBackground(new java.awt.Color(102, 102, 255));
        jLabel39.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(204, 204, 255));
        jLabel39.setText("ID");
        jPanel1.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, 30, 40));

        sizeBox.setFont(new java.awt.Font("Myanmar Text", 1, 18)); // NOI18N
        sizeBox.setForeground(new java.awt.Color(204, 204, 255));
        sizeBox.setFocusable(false);
        sizeBox.setLabel("Size");
        sizeBox.setState(true);
        jPanel1.add(sizeBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, 50));

        jLabel40.setBackground(new java.awt.Color(102, 102, 255));
        jLabel40.setFont(new java.awt.Font("Myanmar Text", 1, 24)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(204, 204, 255));
        jLabel40.setText("Item Type");
        jPanel1.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 120, 30));

        choice1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        choice1.setFocusable(false);
        jPanel1.add(choice1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 350, 110, 40));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_bulleted_list_40px.png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, -1, -1));

        db.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 140, 250, 590));

        jTable1.setAutoCreateRowSorter(true);
        jTable1.setFont(new java.awt.Font("Myanmar Text", 0, 14)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"123", "Shirt", "Fashion", "5", "Medium", null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Item Name", "Item Type", "Qty", "Size", "Action"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jTable1.setFocusable(false);
        jTable1.setGridColor(new java.awt.Color(255, 255, 255));
        jTable1.setIntercellSpacing(new java.awt.Dimension(5, 5));
        jTable1.setOpaque(false);
        jTable1.setRowHeight(40);
        jTable1.setSelectionBackground(new java.awt.Color(153, 153, 153));
        jTable1.setShowHorizontalLines(true);
        jTable1.setShowVerticalLines(true);
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setMinWidth(70);
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(5);
            jTable1.getColumnModel().getColumn(0).setMaxWidth(70);
            jTable1.getColumnModel().getColumn(1).setMinWidth(200);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(10);
            jTable1.getColumnModel().getColumn(1).setMaxWidth(300);
            jTable1.getColumnModel().getColumn(2).setMinWidth(200);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(10);
            jTable1.getColumnModel().getColumn(2).setMaxWidth(300);
            jTable1.getColumnModel().getColumn(3).setMinWidth(100);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(10);
            jTable1.getColumnModel().getColumn(3).setMaxWidth(100);
            jTable1.getColumnModel().getColumn(4).setMinWidth(200);
            jTable1.getColumnModel().getColumn(4).setPreferredWidth(10);
            jTable1.getColumnModel().getColumn(4).setMaxWidth(200);
            jTable1.getColumnModel().getColumn(5).setMinWidth(100);
            jTable1.getColumnModel().getColumn(5).setMaxWidth(100);
        }

        db.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 150, 990, 570));

        getContentPane().add(db, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1460, 740));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
       System.exit(0);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void dragMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMouseDragged
        
        int mouseX = evt.getXOnScreen();
        int mouseY = evt.getYOnScreen();
        
        this.setLocation(mouseX - Xmouse, mouseY - Ymouse);
    }//GEN-LAST:event_dragMouseDragged

    private void dragMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dragMousePressed
       
        Xmouse = evt.getX();
        Ymouse = evt.getY();
        
    }//GEN-LAST:event_dragMousePressed

    private void Item_QtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Item_QtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Item_QtyActionPerformed

    private void Item_TypeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Item_TypeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Item_TypeActionPerformed

    private void Item_NameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Item_NameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Item_NameActionPerformed

    private void Item_idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Item_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Item_idActionPerformed

    private void menu1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu1MousePressed
        pressedColor(menu1);
        resetColor(menu2);
        resetColor(menu3);
    }//GEN-LAST:event_menu1MousePressed

    private void jLabel1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MousePressed

    }//GEN-LAST:event_jLabel1MousePressed

    private void jLabel1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseEntered

    }//GEN-LAST:event_jLabel1MouseEntered

    private void searchBarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_searchBarActionPerformed

    private void menu2MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu2MousePressed
        pressedColor(menu2);
        resetColor(menu1);
        resetColor(menu3);
    }//GEN-LAST:event_menu2MousePressed

    private void menu3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu3MousePressed
        pressedColor(menu3);
        resetColor(menu1);
        resetColor(menu2);
    }//GEN-LAST:event_menu3MousePressed

    private void minimizeMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_minimizeMousePressed
       this.setState(this.ICONIFIED);
    }//GEN-LAST:event_minimizeMousePressed

    private void menu1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu1MouseEntered
         setColor(menu1);
    }//GEN-LAST:event_menu1MouseEntered

    private void menu1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu1MouseExited
        resetColor(menu1);
    }//GEN-LAST:event_menu1MouseExited

    private void menu2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu2MouseEntered
        setColor(menu2);
    }//GEN-LAST:event_menu2MouseEntered

    private void menu2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu2MouseExited
        resetColor(menu2);
    }//GEN-LAST:event_menu2MouseExited

    private void menu3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu3MouseEntered
         setColor(menu3);
    }//GEN-LAST:event_menu3MouseEntered

    private void menu3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menu3MouseExited
         resetColor(menu3);
    }//GEN-LAST:event_menu3MouseExited

    void setColor(JPanel panel) {
        panel.setBackground(new Color(90,118,217));
    }
    void resetColor(JPanel panel) {
        panel.setBackground(new Color(56,75,144));
    }
    void pressedColor(JPanel panel) {
        panel.setBackground(new Color(37,49,96));
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Prototype_01.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Prototype_01.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Prototype_01.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Prototype_01.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Prototype_01().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Item_Name;
    private javax.swing.JTextField Item_Qty;
    private javax.swing.JTextField Item_Type;
    private javax.swing.JTextField Item_id;
    private javax.swing.JPanel Title;
    private javax.swing.JLabel add_button;
    private java.awt.Choice choice1;
    private javax.swing.JPanel db;
    private javax.swing.JPanel drag;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTable jTable1;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JPanel menu1;
    private javax.swing.JPanel menu2;
    private javax.swing.JPanel menu3;
    private javax.swing.JLabel minimize;
    private javax.swing.JTextField searchBar;
    private java.awt.Checkbox sizeBox;
    // End of variables declaration//GEN-END:variables
}
